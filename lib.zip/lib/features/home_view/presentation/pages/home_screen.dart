import 'package:curved_labeled_navigation_bar/curved_navigation_bar.dart';
import 'package:curved_labeled_navigation_bar/curved_navigation_bar_item.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:support_local_artisans/config/routes_manager/routes.dart';
import 'package:support_local_artisans/core/shared/shared_preference.dart';
import 'package:support_local_artisans/core/utils/app_colors.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(
          title: const Text(
            "Support Local Artisans",
            style: TextStyle(color: Colors.white, fontFamily: "Roboto"),
          ),
          centerTitle: true,
          leading: IconButton(
            onPressed: () {
              SharedPreference.removeData(key: "token");
              Navigator.of(context).pushNamedAndRemoveUntil(
                Routes.loginRoute,
                (route) => false,
              );
            },
            icon: Icon(
              Icons.logout,
              color: Colors.white,
              size: 25.sp,
            ),
          ),
          backgroundColor: AppColors.primary,
        ),
        body: Center(
          child: Text(
            "Home Screen",
            style: TextStyle(
              fontSize: 20.sp,
              fontFamily: "Roboto",
              fontWeight: FontWeight.w400,
              color: AppColors.textPrimary,
            ),
          ),
        ),
        bottomNavigationBar: CurvedNavigationBar(
          animationCurve: Curves.easeInOut,
          backgroundColor: AppColors.background,
          color: AppColors.primary,
          buttonBackgroundColor: Colors.orange,
          height: 70.h,
          items: const <CurvedNavigationBarItem>[
            CurvedNavigationBarItem(
                child: Icon(
              Icons.home,
              size: 30,
            )),
            CurvedNavigationBarItem(
                child: Icon(
              Icons.local_fire_department,
              size: 30,
            )),
            CurvedNavigationBarItem(
                child: Icon(
              Icons.settings,
              size: 30,
            )),
          ],
          onTap: (index) {
            // Handle tap events
          },
        ));
  }
}
