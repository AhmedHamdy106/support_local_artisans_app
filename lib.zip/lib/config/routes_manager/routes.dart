class Routes {
  static const String splashRoute = "/";
  static const String loginRoute = "login";
  static const String registerRoute = "register";
  static const String homeRoute = "home";
  static const String forgetPasswordRoute = "forgetPassword";
  static const String verificationCodeRoute = "verificationCode";
  static const String createNewPasswordRoute = "createNewPassword";
}
