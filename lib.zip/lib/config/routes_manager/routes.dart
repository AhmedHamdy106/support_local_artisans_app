class Routes {
  static const String splashRoute = "/";
  static const String loginRoute = "login";
  static const String registerRoute = "register";
  static const String homeRoute = "home";
}
