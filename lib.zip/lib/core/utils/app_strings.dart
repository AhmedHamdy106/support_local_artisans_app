class AppStrings {
  static const String baseUrl = "http://abdoemam.runasp.net";
}