class AppStrings {
  static const String baseUrl = "https://ecommerce.routemisr.com";
}
