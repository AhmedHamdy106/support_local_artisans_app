class EndPoints {
  static const String registerEndPoint = "/api/Account/Register";
  static const String loginEndPoint = "/api/Account/Login";
  static const String forgotPasswordEndPoint = "/api/Account/ForgetPassword";
  static const String verifyCodeEndPoint = "/api/Account/VerifyOTP";
  static const String resetPasswordEndPoint = "/api/Account/ResetPassword";
}
