class EndPoints {
  static const String registerEndPoint = "/api/v1/auth/signup";
  static const String loginEndPoint = "/api/v1/auth/signin";
}
